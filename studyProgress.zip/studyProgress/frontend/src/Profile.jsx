import { Link } from 'react-router-dom';

const ProfilePage = () => {
  return (
  <h1>This is profile page</h1>
    
  );
};

export default ProfilePage;
